package com.zte.agricul.bean;

public class PlotBaseInfo {
	private PlotBaseBean Result ;
	private String Status ;
	public PlotBaseBean getResult() {
		return Result;
	}
	public void setResult(PlotBaseBean result) {
		Result = result;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	
}
