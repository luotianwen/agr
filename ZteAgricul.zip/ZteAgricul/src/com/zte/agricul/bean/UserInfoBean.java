package com.zte.agricul.bean;

public class UserInfoBean {
	private String User_ID;
	private String Job_ID;
	private String Email;
	private String Phone;
	private String Sex;
	private String UserName;
	private String UserImagePath;
	private String UserType;
	private String UserRole;
	public String getUser_ID() {
		return User_ID;
	}
	public void setUser_ID(String user_ID) {
		User_ID = user_ID;
	}
	public String getJob_ID() {
		return Job_ID;
	}
	public void setJob_ID(String job_ID) {
		Job_ID = job_ID;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getPhone() {
		return Phone;
	}
	public void setPhone(String phone) {
		Phone = phone;
	}
	public String getSex() {
		return Sex;
	}
	public void setSex(String sex) {
		Sex = sex;
	}
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getUserImagePath() {
		return UserImagePath;
	}
	public void setUserImagePath(String userImagePath) {
		UserImagePath = userImagePath;
	}
	public String getUserType() {
		return UserType;
	}
	public void setUserType(String userType) {
		UserType = userType;
	}
	public String getUserRole() {
		return UserRole;
	}
	public void setUserRole(String userRole) {
		UserRole = userRole;
	}
	
	
	
}
