package com.zte.agricul.bean;

public class ManagerGrowthBean {
	private String ID ;
	private String Land_ID ;
	private String Crop_Type_ID ;
	private String Data1 ;
	private String Data2 ;
	private String Data3 ;
	private String Data4 ;
	private String Data5 ;
	private String Data6 ;
	private String Data7 ;
	private String Data8 ;
	private String Data9 ;
	private String Data10 ;
	private String Data11 ;
	private String Data12 ;
	private String Data13 ;
	private String Data14 ;
	private String Data15 ;
	private String Data16 ;
	private String Data17 ;
	private String Data18 ;
	private String Data19 ;
	private String Data20 ;
	
	private String AddTime ;
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getLand_ID() {
		return Land_ID;
	}
	public void setLand_ID(String land_ID) {
		Land_ID = land_ID;
	}
	public String getCrop_Type_ID() {
		return Crop_Type_ID;
	}
	public void setCrop_Type_ID(String crop_Type_ID) {
		Crop_Type_ID = crop_Type_ID;
	}
	public String getData1() {
		return Data1;
	}
	public void setData1(String data1) {
		Data1 = data1;
	}
	public String getData2() {
		return Data2;
	}
	public void setData2(String data2) {
		Data2 = data2;
	}
	public String getData3() {
		return Data3;
	}
	public void setData3(String data3) {
		Data3 = data3;
	}
	public String getAddTime() {
		return AddTime;
	}
	public void setAddTime(String addTime) {
		AddTime = addTime;
	}
	public String getData4() {
		return Data4;
	}
	public void setData4(String data4) {
		Data4 = data4;
	}
	public String getData5() {
		return Data5;
	}
	public void setData5(String data5) {
		Data5 = data5;
	}
	public String getData6() {
		return Data6;
	}
	public void setData6(String data6) {
		Data6 = data6;
	}
	public String getData7() {
		return Data7;
	}
	public void setData7(String data7) {
		Data7 = data7;
	}
	public String getData8() {
		return Data8;
	}
	public void setData8(String data8) {
		Data8 = data8;
	}
	public String getData9() {
		return Data9;
	}
	public void setData9(String data9) {
		Data9 = data9;
	}
	public String getData10() {
		return Data10;
	}
	public void setData10(String data10) {
		Data10 = data10;
	}
	public String getData11() {
		return Data11;
	}
	public void setData11(String data11) {
		Data11 = data11;
	}
	public String getData12() {
		return Data12;
	}
	public void setData12(String data12) {
		Data12 = data12;
	}
	public String getData13() {
		return Data13;
	}
	public void setData13(String data13) {
		Data13 = data13;
	}
	public String getData14() {
		return Data14;
	}
	public void setData14(String data14) {
		Data14 = data14;
	}
	public String getData15() {
		return Data15;
	}
	public void setData15(String data15) {
		Data15 = data15;
	}
	public String getData16() {
		return Data16;
	}
	public void setData16(String data16) {
		Data16 = data16;
	}
	public String getData17() {
		return Data17;
	}
	public void setData17(String data17) {
		Data17 = data17;
	}
	public String getData18() {
		return Data18;
	}
	public void setData18(String data18) {
		Data18 = data18;
	}
	public String getData19() {
		return Data19;
	}
	public void setData19(String data19) {
		Data19 = data19;
	}
	public String getData20() {
		return Data20;
	}
	public void setData20(String data20) {
		Data20 = data20;
	}
	
	
	
}
