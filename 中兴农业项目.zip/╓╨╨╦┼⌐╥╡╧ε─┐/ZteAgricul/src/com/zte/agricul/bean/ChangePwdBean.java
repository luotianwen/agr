package com.zte.agricul.bean;

public class ChangePwdBean {
	private String Result;
	private String Status ;
	public String getResult() {
		return Result;
	}
	public void setResult(String result) {
		Result = result;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	
}
