package com.zte.agricul.bean;

public class WeatherBean {
	private String c ;
	private String w ;
	private String w_night ;
	private String c_night ;
	private String time ;
	public String getC() {
		return c;
	}
	public void setC(String c) {
		this.c = c;
	}
	public String getW() {
		return w;
	}
	public void setW(String w) {
		this.w = w;
	}
	public String getW_night() {
		return w_night;
	}
	public void setW_night(String w_night) {
		this.w_night = w_night;
	}
	public String getC_night() {
		return c_night;
	}
	public void setC_night(String c_night) {
		this.c_night = c_night;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	
}
