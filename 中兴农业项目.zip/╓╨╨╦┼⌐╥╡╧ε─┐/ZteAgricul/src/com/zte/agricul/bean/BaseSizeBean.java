package com.zte.agricul.bean;

public class BaseSizeBean {
	private String size  ;

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}
	
}
