package com.zte.agricul.bean;

public class GrowthLogInfo {
	private String Status ;
	private GrowthLogBean  Result ;
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public GrowthLogBean getResult() {
		return Result;
	}
	public void setResult(GrowthLogBean result) {
		Result = result;
	}
	
	
}
