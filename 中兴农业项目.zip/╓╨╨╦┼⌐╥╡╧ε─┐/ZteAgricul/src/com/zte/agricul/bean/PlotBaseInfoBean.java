package com.zte.agricul.bean;

public class PlotBaseInfoBean {

}
