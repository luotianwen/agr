package com.zte.agricul.bean;

public class AgriculMainPopInfo {
	private String Status ;
	private AgriculMainPopBean  Result ;
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public AgriculMainPopBean getResult() {
		return Result;
	}
	public void setResult(AgriculMainPopBean result) {
		Result = result;
	}
	
	
}
