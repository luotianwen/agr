package com.zte.agricul.bean;

public class AgriculMainInfo {
	private String Status ;
	private AgriculMainBean  Result ;
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public AgriculMainBean getResult() {
		return Result;
	}
	public void setResult(AgriculMainBean result) {
		Result = result;
	}
	
	
}
