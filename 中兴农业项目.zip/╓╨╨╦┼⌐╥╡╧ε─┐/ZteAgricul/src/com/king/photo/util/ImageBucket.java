package com.king.photo.util;

import java.util.List;

public class ImageBucket {
	public int count = 0;
	public String bucketName;
	public List<ImageItem> imageList;

}
